import java.util.ArrayList;
//Total: tong so tien can dong
//balance: so tien da dong
// outstanding_fee: so tien con lai can dong
public class Student {
	private int ID;
	private String student_name;
	private int student_year;
	private ArrayList<Course> courses_enrolled;
	private String mail;
	private float balance;
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public int getStudent_year() {
		return student_year;
	}
	public void setStudent_year(int student_year) {
		this.student_year = student_year;
	}
	public ArrayList<Course> getAssign_Couse() {
		return courses_enrolled;
	}
	public void setAssign_Couse(ArrayList<Course> courses_enrolled) {
		this.courses_enrolled = courses_enrolled;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	/**
	 * Task1: nhap so luong sinh vien: Lam o main
	 * Tinh tong fee trong course
	 * @return totalfee
	 */
	public float totalFee() {
		float total_fee =0;
		for (Course course : courses_enrolled) {
			total_fee += course.getFee();	
		}
		return total_fee;
	}
}
