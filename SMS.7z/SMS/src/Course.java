
public class Course {
	private int year;
	private int code;
	private String name_course;
	private float fee;
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName_course() {
		return name_course;
	}
	public void setName_course(String name_course) {
		this.name_course = name_course;
	}
	public float getFee() {
		return fee;
	}
	public void setFee(float fee) {
		this.fee = fee;
	}
	@Override
	public String toString() {
		return "Course [year=" + year + ", code=" + code + ", name_course=" + name_course + ", fee=" + fee + "]";
	}
	
}
