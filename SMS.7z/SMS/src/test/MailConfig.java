package test;

public class MailConfig {
	public static final String HOST_NAME = "smtp.gmail.com";
	public static final int SSL_PORT = 465; 
	public static final int TSL_PORT= 587;
	public static final String APP_EMAIL ="pgsepfshoangminhtruong@gmail.com";
	public static final String APP_PASSWORD = "jlea ikyw qtcs gnym"; // your password
    public static final String RECEIVE_EMAIL = "pgsepfshoangminhtruong@gmail.com";
    //public String RECEIVE_EMAIL; 
}
