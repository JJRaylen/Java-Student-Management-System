
public class TestAS1 {

}
