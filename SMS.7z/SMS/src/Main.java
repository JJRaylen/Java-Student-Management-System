import java.util.Scanner;

public class Main {
	static Scanner sc = new Scanner(System.in);
	/**
	 * Task1: Nhap so luong sinh vien -> NHap thong tin sinh vien
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("How many student will be added?:");
		int numb_student = sc.nextInt();
		System.out.println("Start input student info---------");
		for(int i=0;i<numb_student;i++) {
			Student student = new Student();
			System.out.println("Input Code Student"+i+1);
			student.setID(sc.nextInt());
			System.out.println("Input Name Student"+i+1);
			student.setStudent_name(sc.nextLine());
			System.out.println("Input year Student"+i+1);
			student.setStudent_year(sc.nextInt());
			System.out.println("Input mail Student"+i+1);
			student.setMail(sc.nextLine());
			
		}
	}
}
