package main;

public class Course {
	@Override
	public String toString() {
		return "\n:" +code + ":"+ course_Name + ", fees:" + fees +",";
		//return "Course [year=" + year + ", code=" + code + ", course_Name=" + course_Name + ", fees=" + fees + "]\n";
		//return "Courses:["+ code + "]";
	}

	private int year;
	private int code;
	private String course_Name;
	private int fees;
	
	//Constructor
	public Course(int year, int code, String course_Name, int fees) {
		this.year = year;
		this.code = code;
		this.course_Name = course_Name;
		this.fees = fees;
	}	
	
}
