package main;

import java.util.ArrayList;

public class Student {
	private int id_Student;
	private String nameStudent;
	private int year;
	private ArrayList<Course> attendance_Course = new ArrayList<Course>();
	private int totalFees;
	private int ballance;
	private int remain;
	private String email;
	//Bổ Sung Mail + Gender
	
	// Constructor
	public Student(int id_Student, String nameStudent, int year, String mail) {
	
		this.id_Student = id_Student;
		this.nameStudent = nameStudent;
		this.year = year;
		this.email=mail;
		//this.attendance_Course = attendance_Course;
		//this.ballance = totalFees;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Student(int id_Student, String nameStudent, int year, ArrayList<Course> attendance_Course, int totalFees,
			int ballance, int remain, String email) {
		super();
		this.id_Student = id_Student;
		this.nameStudent = nameStudent;
		this.year = year;
		this.attendance_Course = attendance_Course;
		this.totalFees = totalFees;
		this.ballance = ballance;
		this.remain = remain;
		this.email = email;
	}

	public int getId_Student() {
		return id_Student;
	}

	public void setId_Student(int id_Student) {
		this.id_Student = id_Student;
	}

	public String getNameStudent() {
		return nameStudent;
	}

	public void setNameStudent(String nameStudent) {
		this.nameStudent = nameStudent;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public ArrayList<Course> getAttendance_Course() {
		return attendance_Course;
	}

	public void setAttendance_Course(ArrayList<Course> attendance_Course) {
		this.attendance_Course = attendance_Course;
	}

	public int getTotalFees() {
		return totalFees;
	}

	public int getBallance() {
		return ballance;
	}

	public void setBallance(int ballance) {
		this.ballance = ballance;
	}

	public int getRemain() {
		return remain;
	}

	public void setRemain(int remain) {
		this.remain = remain;
	}

	public Student(int id_Student, String nameStudent, int year, ArrayList<Course> attendance_Course, int totalFees,
			int ballance, int remain) {
		super();
		this.id_Student = id_Student;
		this.nameStudent = nameStudent;
		this.year = year;
		this.attendance_Course = attendance_Course;
		this.totalFees = totalFees;
		this.ballance = ballance;
		this.remain = remain;
	}

	public void setTotalFees(int totalFees) {
		this.totalFees = totalFees;
	}

	@Override
	public String toString() {
		return "id_Student:" + id_Student + "| Name:" + nameStudent + "| Year:" + year
				+ "| attendance_Course:" + attendance_Course + "\nTotal Fee:" + totalFees + "\nBallance: " + ballance+"\nRemain:"+remain;
	}

	//Getter & Setter
	
	
}
