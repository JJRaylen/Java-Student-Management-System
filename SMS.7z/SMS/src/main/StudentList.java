package main;

import java.util.ArrayList;
import java.util.Iterator;

import test.SendMailConfig;

public class StudentList {
	private ArrayList<Student> studentList;
	
	
	//Constructor1
	public StudentList() {
		this.studentList = new ArrayList<Student>();
	}
	//Constructor2
	public StudentList(ArrayList<Student> studentList) {
		this.studentList = studentList;
	}
	
	//1.Add Student
	public void addStudent(Student st) {
		this.studentList.add(st);
	}
	
	//2.Print Student List
	public void printStudentInfo() {
		for (Student student : studentList) {
			System.out.println(student);
		}
	}
	
//	// tìm sinh viên bằng Name
//	public void findStudentByName(String name) {
//		for (Student student : studentList) {
//			if(student.getNameStudent().indexOf(name)>=0){
//				System.out.println(student);
//			}
//		}	
//		}

	//Tìm bằng ID
	public void findStudentByID(int id) {
		for (Student student : studentList) {
			int a = student.getId_Student();
			if(id == a) {
				System.out.println(student);
		}
	}
	}
	// Phải có 1 hàm check Remain: 
	public int checkRemain(int id) {
		int b=0;
		for (Student student : studentList) {
			int a = student.getId_Student();
			if(id == a) {
				b = student.getRemain();
			}
		}
		return b;	
	}
	
	
	//Payment - NHập số tiền cần thanh toán cho sinh viên.
	public void Payment(int id, int money) {
		for (Student student : studentList) {
			int a = student.getId_Student();
			if(id == a) {
				int b = student.getRemain();
				int b1 = student.getBallance();
				student.setRemain(b-money);
				student.setBallance(b1+money);
		}
	}
	}
	
	//Send Mail
		public void SendMailAll() {
			SendMailConfig sm = new SendMailConfig();
			for	(Student student : studentList) {
				sm.SendMail(student.getEmail(),"Dear Candidate,\r\n"+"Congratulations on your successful registration, below is your information:\r\n" + student.toString());
			}
		}
}
